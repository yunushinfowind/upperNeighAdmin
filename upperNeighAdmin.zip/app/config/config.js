module.exports = {
   //HOST: "http://localhost/upperneigh/",
   HOST: "http://192.168.1.81/upperNeighAdmin/",
  //HOST: "http://upperneighbormusic.com:8080/",
  
  // SOUNDURL = "http://upperneighbormusic.com/",
 EMAIL:"yunush.infowind@gmail.com",
 PASS:"21@15together",
 SOUNDSLICE_URL:"www.soundslice.com",
 SOUNDSLICE_USERNAME : "",
 SOUNDSLICE_PASSWORD : "" ,
 SOUNDSLICE_AUTH : "Basic c2JFclNrenFtUkNCRUZxWVBrR2NOTklXdlJWd0lIY0Q6eTlrUGVhOlJmJnEyelh1QXMqXFF0Ji9+TVUyXEpSU1Q=",
 REQUEST_OPTION : {

 }
};
